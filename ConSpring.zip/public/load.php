<?php
    class Load{
        public static $CSS = [
            "addons/font-awesome-4.7.0/css/font-awesome.min.css"
        ];
        public static $JS = [
            
        ];    
    }
?>