<?php
    include('../../unite/invoker/invoke.php');
    class SoleController{
        public static function index(){
            Route::view("sole");
        }
        public static function store(Request $request){
            //code here...
        }
        public static function show(){
            //code here...
        }
        public static function update(){
            //code here...
        }
        public static function destroy(){
            //code here...
        }
        public static function handler(Request $request){
            //code here...
        }
    }
?>