<link rel="stylesheet" href="../../public/addons/font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../../public/assets/css/sole.boostrap/bootstrap.css">
<link rel="stylesheet" href="../../public/assets/css/sole.css">
<link rel="stylesheet" href="../../public/assets/css/sole.toast/toastr.css">
<link rel="stylesheet" href="../../public/assets/css/sole.toast/toastr.min.css">
<link rel="stylesheet" href="../../public/app/app.css">
<script src="../../public/assets/js/sole._jquery/jquery-3.3.1.min.js"></script>
<script src="../../public/assets/js/sole.bootstrap/bootstrap.min.js"></script>
<script src="../../public/assets/js/sole.chart/chart.min.js"></script>
<script src="../../public/assets/js/sole.js"></script>
<script src="../../public/assets/js/sole.landing&error/landing&error.js"></script>
<script src="../../public/assets/js/sole.particle/particles.min.js"></script>
<script src="../../public/assets/js/sole.toast/toastr.min.js"></script>
<script src="../../public/app/app.js"></script>
